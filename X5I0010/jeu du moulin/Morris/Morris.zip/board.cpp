#include "stdafx.h"
#include "board.h"
#include "move.h"
#include "EvalSettings.h"
using std::endl;
using std::cout;
using std::string;

int Board::boardsGenerated = 0;
int Board::boardsDeleted = 0;

// returns the GameState representing the stage of the game.
GameController::GameState Board::getStage() {
	if (_unplaced[GameController::WHITE] > 0 || _unplaced[GameController::BLACK] > 0)
		return GameController::ONE;
	else if (_placed[GameController::WHITE] < 3 || _placed[GameController::BLACK] < 3)
		return GameController::TWO;
	else
		return GameController::THREE;
}
// returns true if the coordinate is one on the board
bool Board::isLegalCoord(char row, char col) {
	bool legal = false;
	if (row == '1' || row == '7') {
		if (col == 'A' || col == 'D' || col == 'G')
			legal = true;
	}
	else if (row == '2' || row == '6') {
		if (col == 'B' || col == 'D' || col == 'F')
			legal = true;
	}
	else if (row == '3' || row == '5') {
		if (col == 'C' || col == 'D' || col == 'E')
			legal = true;
	}
	else if (row == '4')
		if (col == 'A' || col == 'B' || col == 'C' || col == 'E' || col == 'F' || col == 'G')
			legal = true;
	return legal;
}
// returns the index that a col/row combo is stored in (i.e. col A row 1 returns 0)
int Board::getArrayIndex(char row, char col) {
	int index = 0;
	switch (row) {
		case '1':
			if (col == 'A') index = 0;
			else if (col == 'D') index = 1;
			else index = 2;
			break;
		case '2':
			if (col == 'B') index = 3;
			else if (col == 'D') index = 4;
			else index = 5;
			break;
		case '3':
			if (col == 'C') index = 6;
			else if (col == 'D') index = 7;
			else index = 8;
			break;
		case '4':
			if (col == 'A') index = 9;
			else if (col == 'B') index = 10;
			else if (col == 'C') index = 11;
			else if (col == 'E') index = 12;
			else if (col == 'F') index = 13;
			else index = 14;
			break;
		case '5':
			if (col == 'C') index = 15;
			else if (col == 'D') index = 16;
			else index = 17;
			break;
		case '6':
			if (col == 'B') index = 18;
			else if (col == 'D') index = 19;
			else index = 20;
			break;
		default:
			if (col == 'A') index = 21;
			else if (col == 'D') index = 22;
			else index = 23;
			break;
	}
	return index;
}
// returns true if a start position and end position are adjacent to each other (in the sense of a board move)
bool Board::isAdjacent(int startPos, int endPos) {
	if (board[startPos]->up != NULL) {
		if (board[startPos]->up->getLocation() == endPos)
			return true;
	}
	if (board[startPos]->down != NULL) {
		if (board[startPos]->down->getLocation() == endPos)
			return true;
	}
	if (board[startPos]->left != NULL) {
		if (board[startPos]->left->getLocation() == endPos)
			return true;
	}
	if (board[startPos]->right != NULL) {
		if (board[startPos]->right->getLocation() == endPos)
			return true;
	}
	return false;
}
bool Board::isMill(int pos, GameController::Player player) {
	bool ret = false;
	ret = isVerticalMill(pos, player);
	if (!ret)
		ret = isHorizontalMill(pos, player);
	return ret;
}
bool Board::isVerticalMill(int pos, GameController::Player player) {
	bool ret = false;
	if (board[pos]->up == NULL) {  // both neighbors are below
		ret = (board[pos]->down->player == board[pos]->down->down->player) &&
			(board[pos]->down->player == player);
	}
	else if (board[pos]->down == NULL) {  // both above
		ret = (board[pos]->up->player == board[pos]->up->up->player) &&
			(board[pos]->up->player == player);
	}
	else {
		ret = (board[pos]->up->player == board[pos]->down->player) &&
			(board[pos]->up->player == player);
	}
	return ret;
}
bool Board::isHorizontalMill(int pos, GameController::Player player) {
	bool ret = false;
	if (board[pos]->left == NULL) { // both to right
		ret = (board[pos]->right->player == board[pos]->right->right->player) &&
			(board[pos]->right->player == player);
	}
	else if (board[pos]->right == NULL) { // both to left
		ret = (board[pos]->left->player == board[pos]->left->left->player) &&
			(board[pos]->left->player == player);
	}
	else {
		ret = (board[pos]->left->player == board[pos]->right->player) &&
			(board[pos]->left->player == player);
	}
	return ret;
}
void Board::addMoveAndCaptureMoves(Move **moves, int &movesGenerated, int startPos, int endPos) {
	// change the start position to GameController::NEUTRAL, we'll change it back
	board[startPos]->setPlayer(GameController::NEUTRAL);
	if (isMill(endPos, _playerTurn)) {
		int capMoves = 0;
		GameController::Player capPlayer = (_playerTurn == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;
		for (int j = 0; j < 24; j++) {
			if (board[j]->player == capPlayer && !isMill(j, board[j]->player) && movesGenerated < MAX_MOVES) {
				capMoves++;
				Move *m = new Move(Move::MOVE_AND_CAPTURE, startPos, endPos, j);
				moves[movesGenerated++] = m;
			}
		}
		// exception rule.  if all the opponenet's pieces are in mills, we can pull one out
		if (capMoves == 0) {
			for (int j = 0; j < 24; j++) {
				if (board[j]->player == capPlayer && movesGenerated < MAX_MOVES) {
					Move *m = new Move(Move::MOVE_AND_CAPTURE, startPos, endPos, j);
					moves[movesGenerated++] = m;
				}
			}
		}
	}
	else if (movesGenerated < MAX_MOVES) {
		Move *m = new Move(Move::MOVE, startPos, endPos);
		moves[movesGenerated++] = m;
	}
	board[startPos]->setPlayer(_playerTurn);
}
void Board::initialize() {
	boardsGenerated++;
	_unplaced[GameController::WHITE] = 9;
	_unplaced[GameController::BLACK] = 9;
	_placed[GameController::WHITE] = 0;
	_placed[GameController::BLACK] = 0;
    for (int i = 0; i < 24; i++)
		board[i] = new Position(i);
	// now set the up, down, left, and right pointers for each position on board
	board[0]->right = board[1]; board[0]->down = board[9];
	board[1]->left = board[0]; board[1]->down = board[4]; board[1]->right = board[2];
	board[2]->left = board[1]; board[2]->down = board[14];
	board[3]->right = board[4]; board[3]->down = board[10];
	board[4]->left = board[3]; board[4]->right = board[5]; board[4]->up = board[1]; board[4]->down = board[7];
	board[5]->left = board[4]; board[5]->down = board[13];
	board[6]->right = board[7]; board[6]->down = board[11];
	board[7]->left = board[6]; board[7]->right = board[8]; board[7]->up = board[4];
	board[8]->left = board[7]; board[8]->down = board[12];
	board[9]->right = board[10]; board[9]->up = board[0]; board[9]->down = board[21];
	board[10]->left = board[9]; board[10]->right = board[11]; board[10]->up = board[3]; board[10]->down = board[18];
	board[11]->left = board[10]; board[11]->up = board[6]; board[11]->down = board[15];
	board[12]->right = board[13]; board[12]->up = board[8]; board[12]->down = board[17];
	board[13]->left = board[12]; board[13]->right = board[14]; board[13]->up = board[5]; board[13]->down = board[20];
	board[14]->left = board[13]; board[14]->up = board[2]; board[14]->down = board[23];
	board[15]->right = board[16]; board[15]->up = board[11];
	board[16]->left = board[15]; board[16]->right = board[17]; board[16]->down = board[19];
	board[17]->left = board[16]; board[17]->up = board[12];
	board[18]->right = board[19]; board[18]->up = board[10];
	board[19]->left = board[18]; board[19]->right = board[20]; board[19]->up = board[16]; board[19]->down = board[22];
	board[20]->left = board[19]; board[20]->up = board[13];
	board[21]->right = board[22]; board[21]->up = board[9];
	board[22]->left = board[21]; board[22]->right = board[23]; board[22]->up = board[19];
	board[23]->left = board[22]; board[23]->up = board[14];
}
Board::~Board() {
	for (int i = 0; i < 24; i++)
		delete board[i];
	boardsDeleted++;
}
bool Board::allPiecesInMills(GameController::Player player) {
	int piecesInMills = 0;
	for (int i = 0; i < 24; i++) {
		if (board[i]->player == player && isMill(board[i]->getLocation(), player))
			piecesInMills++;
	}
	if (piecesInMills == _placed[player])
		return true;
	else
		return false;
}
GameController::GameState Board::move(const string& command) {
	GameController::GameState state = GameController::ILLEGAL_MOVE;
	// first we need to figure out if it's a placement, placement and capture, move, or move and capture
	if (command.size() == 2) { // it's a placement
		// verify legal coord, we're in stage one, and the current player has a piece to place
		if (isLegalCoord(command[1], command[0]) && getStage() == GameController::ONE && _unplaced[_playerTurn] > 0) {
			int index = getArrayIndex(command[1], command[0]);
			if (board[index]->player == GameController::NEUTRAL) {  // make sure there isn't a piece already there
				board[index]->setPlayer(_playerTurn);  // move
				_unplaced[_playerTurn]--;
				_placed[_playerTurn]++;
				_playerTurn = _playerTurn == GameController::WHITE ? GameController::BLACK : GameController::WHITE;
				state = getStage();
			}
		}
	}
	// next case is either a simple move or a drop and capture
	else if (command.size() == 5) {
		if (command[2] == ',') { // it's a drop and capture
			if (isLegalCoord(command[1], command[0]) && isLegalCoord(command[4], command[3])) {
				int dropPos = getArrayIndex(command[1], command[0]);
				int capturePos = getArrayIndex(command[4], command[3]);
				// verify that the drop forms a mill and the piece they're trying to capture isn't in a mill
				if (isMill(dropPos, _playerTurn) && 
					(!isMill(capturePos, board[capturePos]->player) || allPiecesInMills(board[capturePos]->player))) {
					// make the move
					board[dropPos]->setPlayer(_playerTurn);
                    board[capturePos]->setPlayer(GameController::NEUTRAL);
					_unplaced[_playerTurn]--;
					_placed[_playerTurn]++;
					_playerTurn = _playerTurn == GameController::WHITE ? GameController::BLACK : GameController::WHITE;
					_placed[_playerTurn]--;
					state = getStage();
				}
			}
		}
		else {  // it's a simple move
			// verify both coords are valid
			if (isLegalCoord(command[1], command[0]) && isLegalCoord(command[4], command[3])) {
				int startPos = getArrayIndex(command[1], command[0]);
				int endPos = getArrayIndex(command[4], command[3]);
				// the startPos must be owned by the player and the endPos must be GameController::NEUTRAL
				if (board[startPos]->player == _playerTurn && board[endPos]->player == GameController::NEUTRAL) {
					// the move must be to an adjacent location or if not the player must have only 3 pieces
					if (isAdjacent(startPos, endPos) || _placed[_playerTurn] == 3) {
						// the move is legal, do it and update board state
						board[startPos]->setPlayer(GameController::NEUTRAL);
						board[endPos]->setPlayer(_playerTurn);
						_playerTurn = _playerTurn == GameController::WHITE ? GameController::BLACK : GameController::WHITE;
						state = getStage();
					}
				}
			}
		}
	}
	// last case is a move and capture
	else if (command.size() == 8) {
		// verify all three coords are valid
		if (isLegalCoord(command[1], command[0]) && isLegalCoord(command[4], command[3]) && isLegalCoord(command[7], command[6])) {
			int startPos = getArrayIndex(command[1], command[0]);
			int endPos = getArrayIndex(command[4], command[3]);
			int capPos = getArrayIndex(command[7], command[6]);
			// the startPos must be owned by the player and the endPos must be GameController::NEUTRAL
			// the move must form a mill (endPos)
			// the capPos must also not be in a mill
			if (board[startPos]->player == _playerTurn && 
				board[endPos]->player == GameController::NEUTRAL && 
				isMill(endPos, _playerTurn) &&
				(!isMill(capPos, board[capPos]->player) || allPiecesInMills(board[capPos]->player))) {
				// the move must be to an adjacent location or if not the player must have only 3 pieces
				if (isAdjacent(startPos, endPos) || _placed[_playerTurn] == 3) {
					// the move is legal, do it and update board state
					board[startPos]->setPlayer(GameController::NEUTRAL);
					board[endPos]->setPlayer(_playerTurn);
					board[capPos]->setPlayer(GameController::NEUTRAL);
					_playerTurn = _playerTurn == GameController::WHITE ? GameController::BLACK : GameController::WHITE;
					_placed[_playerTurn]--;
					state = getStage();
				}
			}
		}
	}
	if (hasWon(GameController::BLACK))
		state = GameController::BLACK_WINS;
	else if (hasWon(GameController::WHITE))
		state = GameController::WHITE_WINS;
	return state;
}

std::string Board::getPlayerTurn() {
	if (_playerTurn == GameController::BLACK)
		return "Black";
	else
		return "White";
}
// some functions that are used by the AI to change the board
void Board::drop(int pos) {
	board[pos]->player = _playerTurn;
	_unplaced[_playerTurn]--;
	_placed[_playerTurn]++;
}
void Board::capture(int pos) {
	GameController::Player capPlayer = board[pos]->player;
	board[pos]->setPlayer(GameController::NEUTRAL);
	_placed[capPlayer]--;
}
void Board::move(int startPos, int endPos) {
	board[startPos]->setPlayer(GameController::NEUTRAL);
	board[endPos]->setPlayer(_playerTurn);
}
void Board::changeTurn() {
	_playerTurn = _playerTurn == GameController::WHITE ? GameController::BLACK : GameController::WHITE;
}
GameController::Player Board::getTurn() {
	return _playerTurn;
}
void Board::move(Move &m) {
	if (m.type == Move::DROP)
		drop(m.endPos);
	else if (m.type == Move::DROP_AND_CAPTURE) {
		drop(m.endPos);
		capture(m.capPos);
	}
	else if (m.type == Move::MOVE)
		move(m.startPos, m.endPos);
	else {
		move(m.startPos, m.endPos);
		capture(m.capPos);
	}
	changeTurn();
}
Move **Board::getMoves() {
	Move **moves = new Move*[MAX_MOVES];
	for (int i = 0; i < MAX_MOVES; i++)
		moves[i] = NULL;
	int movesGenerated = 0;
	// if we're in stage one enumerate all the possible drops
	if (_unplaced[_playerTurn] > 0) {
		for (int i = 0; i < 24; i++) {
			if (board[i]->player == GameController::NEUTRAL) {
				if (isMill(i, _playerTurn)) {
					GameController::Player capPlayer = (_playerTurn == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;

					// the capMoves part added for the exception rule.  if all the other player's pieces are in mills
					// we can remove one from them
					int capMoves = 0;
					for (int j = 0; j < 24; j++) {
						if (board[j]->player == capPlayer && !isMill(j, board[j]->player) && movesGenerated < MAX_MOVES) {
							capMoves++;
							Move *m = new Move(Move::DROP_AND_CAPTURE, i, j);
							moves[movesGenerated++] = m;
						}
					}
					// exception rule
					if (capMoves == 0) {
						for (int j = 0; j < 24; j++) {
							if (board[j]->player == capPlayer && movesGenerated < MAX_MOVES) {
								Move *m = new Move(Move::DROP_AND_CAPTURE, i, j);
								moves[movesGenerated++] = m;
							}
						}
					}
					// end exception
				}
				else if (movesGenerated < MAX_MOVES) {
					Move *m = new Move(Move::DROP, i);
					moves[movesGenerated++] = m;
				}
			}
		}
	}
	// if we're in stage two enumerate all the possible adjacent moves
	else if (_placed[_playerTurn] > 3) {
		for (int i = 0; i < 24; i++) {
			// first figure out which pieces we own
			if (board[i]->player == _playerTurn) {
				// now look at each adjacent empty spot
				// for each one, if making the move forms a mill, enumerate the possible captures
				if (board[i]->up != NULL && board[i]->up->player == GameController::NEUTRAL) {
					addMoveAndCaptureMoves(moves, movesGenerated, i, board[i]->up->getLocation());
				}
				if (board[i]->down != NULL && board[i]->down->player == GameController::NEUTRAL) {
					addMoveAndCaptureMoves(moves, movesGenerated, i, board[i]->down->getLocation());
				}
				if (board[i]->left != NULL && board[i]->left->player == GameController::NEUTRAL) {
					addMoveAndCaptureMoves(moves, movesGenerated, i, board[i]->left->getLocation());
				}
				if (board[i]->right != NULL && board[i]->right->player == GameController::NEUTRAL) {
					addMoveAndCaptureMoves(moves, movesGenerated, i, board[i]->right->getLocation());
				}
			}
		}
	}
	// if we're in stage three enumerate all possible move/drops
	else {
		for (int i = 0; i < 24; i++) {
		// first we find which pieces we own
			if (board[i]->player == _playerTurn) {
				// now look at each empty spot
				// for each one, if making the move forms a mill, enumberate the possible captures
				for (int j = 0; j < 24; j++) {
					if (board[j]->player == GameController::NEUTRAL) {
						addMoveAndCaptureMoves(moves, movesGenerated, i, j);
					}
				}
			}
		}
	}
	qsort(moves, movesGenerated, sizeof(Move*), Move::compareMoves);
	return moves;
}
int Board::countMills(GameController::Player startPlayer, GameController::Player player) {
	int ret = 0;
	bool locInH[24];
	bool locInV[24];
	for (int i = 0; i < 24; i++) {
		if (board[i]->player == startPlayer) {
			if (!locInH[i] && isHorizontalMill(i, player)) {
				locInH[i] = true;
				ret++;
				if (board[i]->left == NULL) {
					locInH[board[i]->right->getLocation()] = true;
					locInH[board[i]->right->right->getLocation()] = true;
				}
				else if (board[i]->right == NULL) {
					locInH[board[i]->left->getLocation()] = true;
					locInH[board[i]->left->left->getLocation()] = true;
				}
				else {
					locInH[board[i]->right->getLocation()] = true;
					locInH[board[i]->left->getLocation()] = true;
				}
			}
			if (!locInV[i] && isVerticalMill(i, player)) {
				locInV[i] = true;
				ret++;
				if (board[i]->up == NULL) {
					locInV[board[i]->down->getLocation()] = true;
					locInV[board[i]->down->down->getLocation()] = true;
				}
				else if (board[i]->down == NULL) {
					locInV[board[i]->up->getLocation()] = true;
					locInV[board[i]->up->up->getLocation()] = true;
				}
				else {
					locInV[board[i]->down->getLocation()] = true;
					locInV[board[i]->up->getLocation()] = true;
				}
			}
		}
	}
	//int mill[16];
	//// first add up the horizontal mills
	//if (board[0]->player == startPlayer && isHorizontalMill(0, player))
	//	mill[0]++;
	//if (mill[0] == 0 && board[1]->player == startPlayer && isHorizontalMill(1, player))
	//	mill[0]++;
	//if (mill[0] == 0 && board[2]->player == startPlayer && isHorizontalMill(2, player))
	//	mill[0]++;
	//if (board[3]->player == startPlayer && isHorizontalMill(3, player))
	//	mill[1]++;
	//if (mill[1] == 0 && board[4]->player == startPlayer && isHorizontalMill(4, player))
	//	mill[1]++;
	//if (mill[1] == 0 && board[5]->player == startPlayer && isHorizontalMill(5, player))
	//	mill[1]++;
	//if (board[6]->player == startPlayer && isHorizontalMill(6, player))
	//	mill[2]++;
	//if (mill[2] == 0 && board[7]->player == startPlayer && isHorizontalMill(7, player))
	//	mill[2]++;
	//if (mill[2] == 0 && board[8]->player == startPlayer && isHorizontalMill(8, player))
	//	mill[2]++;
	//if (board[9]->player == startPlayer && isHorizontalMill(9, player))
	//	mill[3]++;
	//if (mill[3] == 0 && board[10]->player == startPlayer && isHorizontalMill(10, player))
	//	mill[3]++;
	return ret;
}
//int Board::countMills(GameController::Player player) {
//	int ret = 0;
//	for (int i = 0; i < 24; i++) {
//		if (i == 0 || i == 1 || i == 2) {
//		}
//	}
//	for (int i = 0; i < 22; i+=3) {
//		if (board[i]->player == player && isHorizontalMill(i, player))
//			ret++;
//	}
//	for (int i = 0; i < 4; i++) {
//		if (board[i]->player == player && isVerticalMill(i, player))
//			ret++;
//	}
//	if (board[5]->player == player && isVerticalMill(5, player))
//		ret++;
//	if (board[6]->player == player && isVerticalMill(6, player))
//		ret++;
//	if (board[8]->player == player && isVerticalMill(8, player))
//		ret++;
//	if (board[16]->player == player && isVerticalMill(16, player))
//		ret++;
//	return ret;
//}
int Board::placedPieces() {
	return _placed[GameController::BLACK] + _placed[GameController::WHITE];
}
int Board::evaluate(EvalSettings& evals) {
	if (getStage() == GameController::ONE) 
		return evalOne(evals);
	else if (getStage() == GameController::TWO)
		return evalTwo(evals);
	else
		return evalThree(evals);
}
int Board::evalTest(EvalSettings& evals) {
	if (getStage() == GameController::ONE) 
		return evalOneTest(evals);
	else if (getStage() == GameController::TWO)
		return evalTwoTest(evals);
	else
		return evalThreeTest(evals);
}
int Board::evalOne(EvalSettings& evals) {
	GameController::Player opponent = (_playerTurn == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;
	int ret = 0;
	// a board in which I lose is the worst!  we can stop right here.
	if (hasWon(opponent))
		return evals.worst_score;
	// a board that gives me an opportunity to form a mill is good
	ret+= (evals.mill_formable*countMills(GameController::NEUTRAL, _playerTurn));
	// give me points for each mill I have
	ret+= (evals.mill_formed*countMills(_playerTurn, _playerTurn));
	// give me points for each mill I blocked
	ret+= (evals.mill_blocked*countMills(_playerTurn, opponent));

	// give me points for each piece I have on the board.  I get points for range of movement
	// this is specific for stage one
	for (int i = 0; i < 24; i++) {
		if (board[i]->player == _playerTurn) {
			if (board[i]->up != NULL)
				ret+= evals.adjacent_spot;
			if (board[i]->down != NULL)
				ret+= evals.adjacent_spot;
			if (board[i]->left != NULL)
				ret+= evals.adjacent_spot;
			if (board[i]->right != NULL)
				ret+= evals.adjacent_spot;
		}
	}
	// give me points for each piece I have captured
	for (int i = 9; i > (_placed[opponent] + _unplaced[opponent]); i--)
		ret+= evals.captured_piece;
	// take away points for each piece my opponent has captured
	for (int i = 9; i > (_placed[_playerTurn] + _unplaced[_playerTurn]); i--)
		ret+= evals.lost_piece;
	// take away points for each mill my opponent has formed
	ret+= (evals.mill_opponent*countMills(opponent, opponent));
	return ret;
}
int Board::evalOneTest(EvalSettings &evals) {
	GameController::Player opponent = (_playerTurn == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;
	int ret = 0;
	// give me points for each piece I have on the board.  I get points for range of movement
	// this is specific for stage one
	for (int i = 0; i < 24; i++) {
		if (board[i]->player == _playerTurn) {
			if (board[i]->up != NULL)
				ret+= evals.adjacent_spot;
			if (board[i]->down != NULL)
				ret+= evals.adjacent_spot;
			if (board[i]->left != NULL)
				ret+= evals.adjacent_spot;
			if (board[i]->right != NULL)
				ret+= evals.adjacent_spot;
		}
	}
	// give me points for each piece I have captured
	for (int i = 9; i > (_placed[opponent] + _unplaced[opponent]); i--)
		ret+= evals.captured_piece;
	// take away points for each piece my opponent has captured
	for (int i = 9; i > (_placed[_playerTurn] + _unplaced[_playerTurn]); i--)
		ret+= evals.lost_piece;
	return ret;
}
int Board::evalTwo(EvalSettings& evals) {
	int ret = 0;
	ret = evalOneTest(evals);
	return ret;
}
int Board::evalTwoTest(EvalSettings& evals) {
	//GameController::Player opponent = (_playerTurn == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;
	//int ret = 0;
	//// a board in which I lose is the worst!  we can stop right here.
	//if (hasWon(opponent))
	//	return evals.worst_score;
	//// a board in which I win is great!
	//if (hasWon(_playerTurn))
	//	return evals.best_score;
	//// give me points for each piece I have captured
	//for (int i = 9; i > (_placed[opponent] + _unplaced[opponent]); i--)
	//	ret+= evals.captured_piece;
	//// take away points for each piece my opponent has captured
	//for (int i = 9; i > (_placed[_playerTurn] + _unplaced[_playerTurn]); i--)
	//	ret+= evals.lost_piece;
	//return ret;
	return evalOne(evals);
}
int Board::evalThree(EvalSettings& evals) {
	int ret = 0;
	ret = evalOneTest(evals);
	return ret;
}
int Board::evalThreeTest(EvalSettings& evals) {
	//GameController::Player opponent = (_playerTurn == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;
	//int ret = 0;
	//// a board in which I lose is the worst!  we can stop right here.
	//if (hasWon(opponent))
	//	return evals.worst_score;
	//// a board in which I win is great!
	//if (hasWon(_playerTurn))
	//	return evals.best_score;
	//// give me points for each piece I have captured
	//for (int i = 9; i > (_placed[opponent] + _unplaced[opponent]); i--)
	//	ret+= evals.captured_piece;
	//// take away points for each piece my opponent has captured
	//for (int i = 9; i > (_placed[_playerTurn] + _unplaced[_playerTurn]); i--)
	//	ret+= evals.lost_piece;
	//return ret;
	return evalOne(evals);
}
// returns true if all the pieces on the board for the player are blocked
bool Board::blocked(GameController::Player player) {
	// check every piece on the board
	for (int i = 0; i < 24; i++) {
		// if it's the player's piece check if it can move
		if (board[i]->player == player) {
			// if it can move up, down, left, or right then the player isn't blocked
			if (board[i]->up != NULL && board[i]->up->player == GameController::NEUTRAL)
				return false;
			if (board[i]->down != NULL && board[i]->down->player == GameController::NEUTRAL)
				return false;
			if (board[i]->left != NULL && board[i]->left->player == GameController::NEUTRAL)
				return false;
			if (board[i]->right != NULL && board[i]->right->player == GameController::NEUTRAL)
				return false;
		}
	}
	// we must be blocked
	return true;
}
bool Board::hasWon(GameController::Player player) {
	GameController::Player opponent = (player == GameController::WHITE) ? GameController::BLACK : GameController::WHITE;
	// if the opponent has unplaced pieces, we're still in stage one and we haven't won
	if (_unplaced[opponent] > 0)
		return false;
	// if the opponent has less than three pieces then we've won!
	if (_placed[opponent] + _unplaced[opponent] < 3)
		return true;
	// if the opponent is blocked then we've won!
	return blocked(opponent);
}
// outputs the board configuration to cout
void Board::print() {
//	cout << "It is the " << getPlayerTurn() << " player's turn." << endl << endl;
	cout << "    A   B   C   D   E   F   G" << endl << endl;
	cout << "1   " << board[0]->getPlayer() << "-----------" << board[1]->getPlayer() << "-----------" << board[2]->getPlayer() << endl;
	cout << "    " << "|           |           |" << endl;
	cout << "2   " << "|   " << board[3]->getPlayer() << "-------" << board[4]->getPlayer() << "-------" << board[5]->getPlayer() << "   |" << endl;
	cout << "    " << "|   |       |       |   |" << endl;
	cout << "3   " << "|   |   " << board[6]->getPlayer() << "---" << board[7]->getPlayer() << "---" <<board[8]->getPlayer() << "   |   |" << endl;
	cout << "    " << "|   |   |       |   |   |" << endl;
	cout << "4   " << board[9]->getPlayer() << "---" << board[10]->getPlayer() << "---" << board[11]->getPlayer() << "       " << board[12]->getPlayer() << "---" << board[13]->getPlayer() << "---" << board[14]->getPlayer() << endl;
	cout << "    " << "|   |   |       |   |   |" << endl;
	cout << "5   " << "|   |   " << board[15]->getPlayer() << "---" << board[16]->getPlayer() << "---" << board[17]->getPlayer() << "   |   |" << endl;
	cout << "    " << "|   |       |       |   |" << endl;
	cout << "6   " << "|   " << board[18]->getPlayer() << "-------" << board[19]->getPlayer() << "-------" << board[20]->getPlayer() << "   |" << endl;
	cout << "    " << "|           |           |" << endl;
	cout << "7   " << board[21]->getPlayer() << "-----------" << board[22]->getPlayer() << "-----------" << board[23]->getPlayer() << endl;
}
