#include "stdafx.h"
#include <time.h>
#include "gamecontroller.h"
#include "board.h"
#include "move.h"
#include "gamenode.h"
#include "EvalSettings.h"
using std::cout;
using std::endl;
using std::string;

/*
CONSTRUCTORS AND DESTRUCTORS
*/
GameController::GameController(int timel, char firstToAct) {
	b = new Board(WHITE);
	_state = ONE;
	time_limit = timel;
	gameOver = false;
	evals = new EvalSettings();
	eval = &Board::evaluate;
	if (firstToAct == 'C') {
		computerColor = WHITE;
		humanColor = BLACK;
		computerMove(*evals, eval);
	}
	else {
		computerColor = BLACK;
		humanColor = WHITE;
	}
}
GameController::GameController(int timel, int gamel, bool evalGoes) {
	b = new Board(WHITE);
	_state = ONE;
	time_limit = timel;
	gameOver = false;
	evals = new EvalSettings();
	while (!isOver()) {
		if (evalGoes) {
			Player me = b->getTurn();
			computerMove(*evals, &Board::evaluate);
			if (b->hasWon(me)) {
				gameOver = true;
				cout << "The evaluate function has won!" << endl;
			}
			evalGoes = false;
		}
		else {
			Player me = b->getTurn();
			computerMove(*evals, &Board::evalTest);
			if (b->hasWon(me)) {
				gameOver = true;
				cout << "The evalTest function has won!" << endl;
			}
			evalGoes = true;
		}
		b->print();
	}
	b->print();
}
GameController::~GameController() {
	delete b;
	delete evals;
}

bool GameController::computerMove(EvalSettings& es, evalFunc ev) {
	bool ret = true;
	eval = ev;
	cout << "Determining computer's move..." << endl;
	Move::MovesGenerated = 0;
	clock_t start, end;
	start = clock();
	GameNode *m = bestMove(start, es);
	end = clock();
	if (m == NULL) {
		if (b->hasWon(BLACK))
			cout << "Black has won!" << endl;
		else if (b->hasWon(WHITE))
			cout << "White has won!" << endl;
		// this next bit is because we didn't find a move.  I'm guessing it's because we're only a move or two away
		// from losing.  So get the list of moves and just toss out the first one.
		else {
			cout << "No best move found. You may be about to win!" << endl;
			Move **moveList = b->getMoves();
			if (moveList[0] != NULL) {
				cout << "Computer move: " << moveList[0]->getMove() << endl;
				b->move(*moveList[0]);
				for (int i = 0; moveList[i] != NULL && i < Board::MAX_MOVES; i++)
					delete moveList[i];
			}
			else {
				cout << "Couldn't find any move!" << endl;
				ret = false;
			}
			delete [] moveList;
		}
	}
	else {
		cout << "      Best Move: ";
		cout << m->move->getMove() << endl;
		cout << "          Score: " << m->score << endl;
		cout << "Moves Generated: " << Move::MovesGenerated << " in " << ((double)(end-start))/(double)CLOCKS_PER_SEC << " seconds." << endl;
		cout << "   " << b->getPlayerTurn() << "'s move: " << m->move->getMove() << endl;
		b->move(*(m->move));
		delete m;
	}
	return ret;
}
/*
PUBLIC FUNCTIONS
*/
bool GameController::move(std::string& strMove) {
	bool ret = false;
	_state = b->move(strMove);
	if (_state != ILLEGAL_MOVE)
		ret = true;
	if (b->hasWon(humanColor)) {
		cout << "You have won!" << endl;
		gameOver = true;
	}
	// now have the computer move
	else if (ret) {
		b->print();
		if (!computerMove(*evals, eval))
			gameOver = true;
		else if (b->hasWon(computerColor)) {
			cout << "The computer has won!" << endl;
			gameOver = true;
		}
	}
	return ret;
}
bool GameController::isOver() {
	return gameOver;
}
void GameController::print() {
	b->print();
	if (b->hasWon(BLACK))
		cout << "Black has won!" << endl;
	else if (b->hasWon(WHITE))
		cout << "White has won!" << endl;

	if (b->getTurn() == computerColor)
		cout << "It is the computer's move." << endl;
	else
		cout << "Enter move: ";
}
GameNode *GameController::bestMove(clock_t start, EvalSettings& es) {
	// set depth based on the number of moves returned for htis board.
	// this is pretty loose but will give us an idea of how bad the branching factor is right now

	// Move **moves = b->getMoves();
	//int branching = 0;
	//while (moves[branching] != NULL) {
	//	branching++;
	//}
	//for (int i = 0; i < branching; i++)
	//	delete moves[i];
	//delete [] moves;

	//if (branching < 4)
	//	depth = 8;
	//else if (branching < 10)
	//	depth = 6;
	//cout << "Branching Estimate: " << branching << endl;
	clock_t now = clock();
	startTime = start;
	GameNode *best = NULL;
	evals = &es;
	hitTimeCutoff = false;
	for (int depth = 2; ((double)(now-startTime))/(double)CLOCKS_PER_SEC < time_limit; depth+= 2) {
		GameNode *temp = NULL;
		cout << "Searching to depth: " << depth << endl;
		temp = bestMove(b, depth,  es.worst_score, es.best_score);
		now = clock();
		if (hitTimeCutoff) {
			cout << "Time limit reached before finding best move at this depth." << endl << endl;
		}
		else if (temp != NULL && temp->move != NULL) {
			if (best != NULL)
				delete best;
			best = temp;
			cout << "Move " << best->move->getMove() << " found in " << ((double)(now-startTime))/(double)CLOCKS_PER_SEC << " seconds." << endl;
		}
		else if (temp == NULL)
			break;
	}
	return best;
}

/*
 PRIVATE FUNCTIONS
*/

GameNode *GameController::bestMove(Board *b, int depth, int mybest, int hisbest) {
	if (depth == 0)
		return new GameNode((b->*eval)(*evals), NULL);
	clock_t now = clock();
	if (((double)(now-startTime))/(double)CLOCKS_PER_SEC > time_limit) {
		hitTimeCutoff = true;
		return NULL;
	}

	Move **moveList = b->getMoves();
	int movesEvaluated = 0;
	int bestScore = mybest;
	Move *bestMove = NULL;
	while (moveList[movesEvaluated] != NULL && movesEvaluated < Board::MAX_MOVES) {
		Board *evalBoard = new Board(*b);
		evalBoard->move(*moveList[movesEvaluated]);
		GameNode *attempt = GameController::bestMove(evalBoard, depth - 1, 0 - hisbest, 0 - bestScore);
		if (attempt != NULL && (0 - attempt->score) > bestScore) {
			bestScore = (0 - attempt->score);
			delete attempt;
			if (bestMove != NULL)
				delete bestMove;
			bestMove = new Move(*moveList[movesEvaluated]);
		}
		else if (attempt != NULL) {
			delete attempt;
		}
		delete evalBoard;
		if (bestScore > hisbest)
			break;
		movesEvaluated++;
	}

	// free memory!
	movesEvaluated = 0;
	while (moveList[movesEvaluated] != NULL && movesEvaluated < Board::MAX_MOVES) {
		delete moveList[movesEvaluated];
		movesEvaluated++;
	}
	delete [] moveList;

	return new GameNode(bestScore, bestMove);
}