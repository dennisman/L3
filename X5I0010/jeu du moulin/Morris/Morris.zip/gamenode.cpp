#include "stdafx.h"
#include "gamenode.h"
#include "move.h"

GameNode::GameNode(int s, Move *m) : score(s), move(m) {}

GameNode::~GameNode() {
	if (move != NULL) {
		delete move;
	}
}