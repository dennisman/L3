#include "stdafx.h"
#include "move.h"
#include "board.h"
using std::string;

int Move::MovesGenerated = 0;
int Move::movesDeleted = 0;

bool operator<(Move const& lhs, Move const& rhs) {
	return lhs.score < rhs.score;
}
Move::Move(MoveType t, int pos1) : type(t), endPos(pos1) {
	init();
}
Move::Move(int s) : score(s) {
	MovesGenerated++;
}
Move::Move(MoveType t, int pos1, int pos2) : type(t) {
	if (t == DROP_AND_CAPTURE) {
		endPos = pos1;
		capPos = pos2;
	}
	else if (t == MOVE) {
		startPos = pos1;
        endPos = pos2;
	}
	init();
}
Move::Move(MoveType t, int sPos, int ePos, int cPos) : type(t), startPos(sPos), endPos(ePos), capPos(cPos) {
	init();
}
Move::Move(const Move& m) {
	startPos = m.startPos;
	endPos = m.endPos;
	capPos = m.capPos;
	score = m.score;
	type = m.type;
	MovesGenerated++;
}
Move::~Move() {
	movesDeleted++;
}
int Move::compareMoves(const void *a, const void *b) {
	Move * aa = *(Move **)a;
	Move * bb = *(Move **)b;
	return (aa->type > bb->type) ? -1 : (aa->type < bb->type) ? 1: 0;
}
string Move::getHumanLocation(int index) {
	string ret;
	switch (index) {
		case 0:
			ret = "A1";
			break;
		case 1:
			ret = "D1";
			break;
		case 2:
			ret = "G1";
			break;
		case 3:
			ret = "B2";
			break;
		case 4:
			ret = "D2";
			break;
		case 5:
			ret = "F2";
			break;
		case 6:
			ret = "C3";
			break;
		case 7:
			ret = "D3";
			break;
		case 8:
			ret = "E3";
			break;
		case 9:
			ret = "A4";
			break;
		case 10:
			ret = "B4";
			break;
		case 11:
			ret = "C4";
			break;
		case 12:
			ret = "E4";
			break;
		case 13:
			ret = "F4";
			break;
		case 14:
			ret = "G4";
			break;
		case 15:
			ret = "C5";
			break;
		case 16:
			ret = "D5";
			break;
		case 17:
			ret = "E5";
			break;
		case 18:
			ret = "B6";
			break;
		case 19:
			ret = "D6";
			break;
		case 20:
			ret = "F6";
			break;
		case 21:
			ret = "A7";
			break;
		case 22:
			ret = "D7";
			break;
		case 23:
			ret = "G7";
			break;
	}
	return ret;
}
string Move::getMove() {
    if (type == DROP)
		return getHumanLocation(endPos);
	else if (type == DROP_AND_CAPTURE)
		return getHumanLocation(endPos) + "," + getHumanLocation(capPos);
	else if (type == MOVE)
		return getHumanLocation(startPos) + "-" + getHumanLocation(endPos);
	else
		return getHumanLocation(startPos) + "-" + getHumanLocation(endPos) + "," + getHumanLocation(capPos);
}
/*
PRIVATE FUNCTIONS
*/
void Move::init() {
	//board = new Board(*b);
	//board->move(*this);
	//board->changeTurn();
	//score = board->evaluate();
	//board->changeTurn();
	MovesGenerated++;
}