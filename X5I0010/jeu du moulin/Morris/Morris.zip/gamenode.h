#ifndef GAMENODE_H
#define GAMENODE_H

class Move;

class GameNode {
public:
	GameNode(int s, Move *m);
	~GameNode();
	int score;
	Move *move;
};

#endif