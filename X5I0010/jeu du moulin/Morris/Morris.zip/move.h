#ifndef MOVE_H
#define MOVE_H
#include "stdafx.h"
using std::string;

class Move {
private:
	void init();
public:
	static int MovesGenerated;
	static int movesDeleted;
	enum MoveType {
		DROP,
		MOVE,
		DROP_AND_CAPTURE,
		MOVE_AND_CAPTURE
	};
	int score;
	int startPos;
	int endPos;
	int capPos;
	MoveType type;
	Move(MoveType t, int pos1);
	Move(int s);
	Move(MoveType t, int pos1, int pos2);
	Move(MoveType t, int sPos, int ePos, int cPos);
	Move(const Move& m);
	~Move();
	friend bool operator<(Move const& lhs, Move const& rhs);
	static int compareMoves(const void *a, const void *b);
	string getHumanLocation(int index);
	string getMove();
};

#endif