#ifndef BOARD_H
#define BOARD_H
#include "stdafx.h"
#include "position.h"
#include "gamecontroller.h"

class Move;
class EvalSettings;

class Board {
private:
	GameController::Player _playerTurn;
	Position * board[24];
	char _unplaced[2];
	char _placed[2];
	// returns the GameState representing the stage of the game.
	GameController::GameState getStage();
	// returns true if the coordinate is one on the board
	bool isLegalCoord(char row, char col);
	// returns the index that a col/row combo is stored in (i.e. col A row 1 returns 0)
	int getArrayIndex(char row, char col);
	// returns true if a start position and end position are adjacent to each other (in the sense of a board move)
	bool isAdjacent(int startPos, int endPos);
	bool isMill(int pos, GameController::Player player);
	bool isVerticalMill(int pos, GameController::Player player);
	bool isHorizontalMill(int pos, GameController::Player player);
	void addMoveAndCaptureMoves(Move **moves, int &movesGenerated, int startPos, int endPos);
	void initialize();
	bool allPiecesInMills(GameController::Player player);
public:
	static const int MAX_MOVES = 50;
	static int boardsGenerated;
	static int boardsDeleted;
	Board(GameController::Player pplayer) : _playerTurn(pplayer) {
		initialize();
	}
	Board(const Board& b) {
		// first initialize as blank new board
		initialize();
		// now do the deep copy stuff
		_unplaced[GameController::WHITE] = b._unplaced[GameController::WHITE];
		_unplaced[GameController::BLACK] = b._unplaced[GameController::BLACK];
		_placed[GameController::WHITE] = b._placed[GameController::WHITE];
		_placed[GameController::BLACK] = b._placed[GameController::BLACK];
		_playerTurn = b._playerTurn;
		for (int i = 0; i < 24; i++)
		board[i]->player = b.board[i]->player;
	}
	~Board();
	int placedPieces();
	GameController::GameState move(const std::string& command);
	std::string getPlayerTurn();
	// some functions that are used by the AI to change the board
	void drop(int pos);
	void capture(int pos);
	void move(int startPos, int endPos);
	void changeTurn();
	GameController::Player getTurn();
	void move(Move &m);
	Move **getMoves();
	int countMills(GameController::Player startPlayer, GameController::Player player);
	int evaluate(EvalSettings& evals);
	int evalTest(EvalSettings& evals);
	int evalOne(EvalSettings& evals);
	int evalOneTest(EvalSettings& evals);
	int evalTwo(EvalSettings& evals);
	int evalTwoTest(EvalSettings& evals);
	int evalThree(EvalSettings& evals);
	int evalThreeTest(EvalSettings& evals);
	// returns true if all the pieces on the board for the player are blocked
	bool blocked(GameController::Player player);
	bool hasWon(GameController::Player player);
	// outputs the board configuration to cout
	void print();
};

#endif