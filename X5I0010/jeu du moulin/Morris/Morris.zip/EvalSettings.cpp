#include "stdafx.h"
#include "evalsettings.h"
using std::string;

EvalSettings::EvalSettings() : mill_formable(50), mill_formed(120), mill_blocked(40), mill_opponent(120), captured_piece(100), lost_piece(-110), adjacent_spot(2), worst_score(-10000), best_score(10000) {}

EvalSettings::EvalSettings(std::string& file) {
}