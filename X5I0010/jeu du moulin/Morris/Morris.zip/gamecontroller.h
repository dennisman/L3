#ifndef GAMECONTROLLER_H
#define GAMECONTROLLER_H

#include "stdafx.h"
#include <time.h>

class Board;
class Move;
class GameNode;

class EvalSettings;

class GameController {
public:
	typedef int (Board::*evalFunc)(EvalSettings& evals);
	enum GameState {
		WHITE_WINS,
		BLACK_WINS,
		ILLEGAL_MOVE,
		ONE,
		TWO,
		THREE
	};
	enum Player {
		WHITE,
		BLACK,
		NEUTRAL
	};
	GameController(int timel, char firstToAct);
	GameController(int timel, int gamel, bool evalGoes);
	~GameController();
	bool move(std::string& strMove);
	bool isOver();
	GameNode *bestMove(clock_t start, EvalSettings& es);
	void print();
private:
	bool computerMove(EvalSettings& es, evalFunc ev);
	bool gameOver;
	int time_limit;
	Player computerColor;
	Player humanColor;
	bool hitTimeCutoff;
	EvalSettings *evals;
	evalFunc eval;
	clock_t startTime;
	GameNode *bestMove(Board *b, int depth, int mybest, int hisbest);
	Board *b;
	GameState _state;
};
#endif