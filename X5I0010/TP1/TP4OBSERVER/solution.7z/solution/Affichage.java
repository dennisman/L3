class Affichage extends Observer
{
  public Affichage( Sujet s ) { super(s); }
}
