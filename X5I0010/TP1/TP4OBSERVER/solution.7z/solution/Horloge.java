class Horloge extends Sujet { }
