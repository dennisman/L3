interface CrypteStrategy
{
  public String encode(String s);
}