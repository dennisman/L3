#!/bin/bash

rm *~ *.class -f
