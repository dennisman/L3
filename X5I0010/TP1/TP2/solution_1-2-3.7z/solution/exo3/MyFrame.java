interface MyFrame
{
  public void affiche();
  public void setSize(int x, int y);
  public void setTitle(String s);
}