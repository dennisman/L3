import java.util.*;

interface DateFormatStrat
{
  String formatStrat( Date date );
}