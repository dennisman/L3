class Main
{
  public static void main( String argv[] )
  {
    DBManager manager = new DBManager();
    manager.printMolecule( "ethanol" );
    manager.printMolecule( "eau" );
    manager.printMolecule( "methanol" );
  }
}
