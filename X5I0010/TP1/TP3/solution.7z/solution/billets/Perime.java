class Perime extends Etat
{
  public Perime( Billet billet ) { super( billet ); }
}
