let
  ch = read_line ()
in
  (print_int (String.length (ch)) ;
   print_newline ())
